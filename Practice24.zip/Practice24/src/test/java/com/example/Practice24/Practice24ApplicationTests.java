package com.example.Practice24;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Practice24ApplicationTests {

	@Test
	void contextLoads() {
	}

}
