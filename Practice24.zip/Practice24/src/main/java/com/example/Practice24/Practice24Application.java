package com.example.Practice24;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Practice24Application {

	public static void main(String[] args) {
		SpringApplication.run(Practice24Application.class, args);
	}

}
